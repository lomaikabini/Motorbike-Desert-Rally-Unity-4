var searchData=
[
  ['progressupdatedelegate',['ProgressUpdateDelegate',['../namespace_digital_opus_1_1_m_b_1_1_core.html#a010baff935764e19e32134ce62295921',1,'DigitalOpus::MB::Core']]]
];
