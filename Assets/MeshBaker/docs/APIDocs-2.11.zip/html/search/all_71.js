var searchData=
[
  ['quick',['quick',['../namespace_digital_opus_1_1_m_b_1_1_core.html#a9412ea8d3114e6a024a115e96b67d38ca1df3746a4728276afdc24f828186f73a',1,'DigitalOpus::MB::Core']]]
];
