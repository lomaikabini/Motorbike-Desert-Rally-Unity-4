var searchData=
[
  ['objectlog',['ObjectLog',['../class_digital_opus_1_1_m_b_1_1_core_1_1_object_log.html#a9770a2e011eaf80bdde1f0f4791695a0',1,'DigitalOpus::MB::Core::ObjectLog']]]
];
