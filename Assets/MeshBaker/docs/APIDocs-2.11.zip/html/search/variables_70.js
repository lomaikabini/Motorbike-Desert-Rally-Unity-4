var searchData=
[
  ['packingalgorithm',['packingAlgorithm',['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___texture_combiner.html#a908a15ccbb0d3c00db8dc7cfd8f810f1',1,'DigitalOpus::MB::Core::MB_TextureCombiner']]],
  ['prefabuvrects',['prefabUVRects',['../class_m_b2___texture_bake_results.html#af1b5bc5755e084b8409d865e011711e3',1,'MB2_TextureBakeResults']]]
];
